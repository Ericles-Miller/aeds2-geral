#include <stdio.h>
#include <stdlib.h>
#include "stack.h"


TStack * build_stack(int size)
{
	TStack *aux = (TStack*)malloc(sizeof(TStack));
	aux->top = -1;
	aux->S = (void**)malloc(sizeof(void*)*size);
	aux->size = size;
	return aux;
}

int stack_empty( TStack *s)
{
	if(s->top >= 0 )
	{
		return 0;
	}
	return 1;
}

void push(TStack *s, void *elem)
{
	if( s->top != s->size -1 )
	{
		s->top++;
		s->S[s->top] = elem;
	}
	else
	{
		printf("stack full\n");
	}
}

void* pop(TStack *s)
{
	void *aux;
	
	if( !stack_empty(s) )
	{
		aux = s->S[ s->top ];
		s->top--;
		return aux;
	}
	else
	{
		printf("Stack empty\n");
		return NULL;
	}
}

void free_stack(TStack * s, void (*free_elem)())
{
	void *aux;
	while( !stack_empty( s ) )
	{
		aux = pop(s);
		free_elem(aux);
	}
	free(s->S);
	free(s);
}

