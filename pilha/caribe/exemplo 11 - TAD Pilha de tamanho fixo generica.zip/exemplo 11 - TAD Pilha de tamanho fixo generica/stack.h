
#ifndef STACK_H
#define STACK_H

typedef struct stack TStack;
struct stack
{
	int size;
	int top;
	void **S;
};

TStack * build_stack(int);
int stack_empty( TStack *s);
void push(TStack *, void *);
void * pop(TStack *s);
void free_stack(TStack *, void (*free_elem)());

#endif