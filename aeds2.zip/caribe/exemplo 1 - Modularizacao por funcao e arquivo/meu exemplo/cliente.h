#ifndef CLIENTE_H
#define CLIENTE_H

typedef struct cliente tcliente;
struct cliente
{
    char nome[30];
    char cpf[15];
};



#endif // DEBUG
