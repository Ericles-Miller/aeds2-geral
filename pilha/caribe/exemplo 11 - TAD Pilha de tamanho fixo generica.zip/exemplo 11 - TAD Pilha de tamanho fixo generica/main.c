#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "stack.h"

#define N 3


typedef struct disciplina TDisciplina;
struct disciplina
{
	char nome[30];
};

typedef struct aluno TAluno;
struct aluno
{
	char nome[30];
	TDisciplina *disciplinas;
	int qtd;
};

void desalocar_aluno( TAluno *a )
{
	free(a->disciplinas);
	free(a);
}

void desalocar_disciplina( TDisciplina *d )
{
	free(d);
}


int main()
{
	TAluno *aux;
	TDisciplina *aux2;
	TStack *s;
	void (*pf)();
		
	s = build_stack(N);
	
	aux = (TAluno*)malloc(sizeof(TAluno));
	aux->disciplinas = (TDisciplina*)malloc(sizeof(TDisciplina));
	strcpy(aux->nome, "Ana");
	strcpy(aux->disciplinas->nome, "AEDsI");
	push(s, aux);

	aux = (TAluno*)malloc(sizeof(TAluno));
	aux->disciplinas = (TDisciplina*)malloc(sizeof(TDisciplina));
	strcpy(aux->nome, "Jose");
	strcpy(aux->disciplinas->nome, "AEDsII");
	push(s, aux);
	
	aux = (TAluno*)malloc(sizeof(TAluno));
	aux->disciplinas = (TDisciplina*)malloc(sizeof(TDisciplina));
	strcpy(aux->nome, "Pedro");
	strcpy(aux->disciplinas->nome, "AEDsI");
	push(s, aux);
	
	pf = &desalocar_aluno;
	free_stack(s, pf);
	
	s = build_stack(N);
	aux2 = (TDisciplina*)malloc(sizeof(TDisciplina));
	strcpy(aux2->nome,"AEDsI");
	push(s, aux2);
	
	aux2 = (TDisciplina*)malloc(sizeof(TDisciplina));
	strcpy(aux2->nome,"AEDsII");
	push(s, aux2);
	
	aux2 = (TDisciplina*)malloc(sizeof(TDisciplina));
	strcpy(aux2->nome,"AEDsIII");
	push(s, aux2);
	
	pf = &desalocar_disciplina;
	free_stack(s, pf);

	return 0;
}